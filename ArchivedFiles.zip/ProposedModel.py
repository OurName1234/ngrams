#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 24 20:06:57 2022

@author: jfs
"""

import time
import math
import random
import time


import numpy as np
from DistKBD import fillTrainingDistk




# to predict W(k,C;L,n) 	
   
def Wk(k,Corpus,Lang,NgranSize):
    from Vocabulary import fillVoc
    from TrainingCorpora import fillTrainingCorpora
    TrainingCorpora={}; fillTrainingCorpora(TrainingCorpora)
    (C1,C2)=TrainingCorpora[(Lang,NgranSize)]
    Voc={}; fillVoc(Voc)
    V=Voc[(Lang,NgranSize)]
    Distk={}; fillTrainingDistk(Distk);
    (gk1,hk1)=gkhk(Lang,NgranSize,V,C1,C2,k,Distk)
    (gk2,hk2)=gkhk(Lang,NgranSize,V,C1,C2,k+1,Distk)
    prevDk=CalcD(V, gk1, hk1, Corpus)
    prevDkplus1=CalcD(V, gk2, hk2, Corpus)
    prevWk=prevDk-prevDkplus1
    print('Prediction for Corpus ',Corpus,', k=',k,' for ',str(NgranSize)+'-grams in language ',Lang,': ',prevWk)
    	        
        

# To estimate the vocabulary size

def EstimateVocabularySize(Lang,Size,Vini,Vfin,Vstep,Trainingcorpora,Lk):
    from WkBD import fillTrainingWk
    niters=(Vfin - Vini)/Vstep
    print('It may take about ', 210* niters/394650,' seconds')
    Wk={}; fillTrainingWk(Wk); Distk={}; fillTrainingDistk(Distk)
    V=Vini; BestRMSRE=99999
    NumSteps= (Vfin - Vini)/Vstep
    while(V<=Vfin):
        WkAbsErrorsinCorpora=[]
        C1=Trainingcorpora[0]; C2=Trainingcorpora[1]
        ErrAcumAllWk(Lang,Size,V,C1,C2,Trainingcorpora,Lk,WkAbsErrorsinCorpora,Wk,Distk)
        WkAbsErrorsinCorpora=np.array(WkAbsErrorsinCorpora)
        AvgErr=np.mean(WkAbsErrorsinCorpora); RMSRE=(np.mean(WkAbsErrorsinCorpora**2))**0.5
        if(RMSRE < BestRMSRE):
            BestRMSRE=RMSRE; BestV=V
        V = V + Vstep
    print('Vocabulary size and Errors for',str(Size)+'-grams:')
    print(' Vocabulary size estimate --',BestV,str(Size)+'-grams')
    print(' Average Relative Error --',str(AvgErr * 100)+'%')
    print(' Root Mean Square of the Relative Error --',str(BestRMSRE * 100)+'%')      
    

	


def ErrAcumAllWk(Lang,Size,V,C1,C2,Lcorpora,Lk,WkAbsErrorsinCorpora,Wk,Distk):
    for i in range(len(Lk)):
        k=Lk[i]
        ErrAcumWk(Lang,Size,V,C1,C2,k,Lcorpora,WkAbsErrorsinCorpora,Wk,Distk)
  

def ErrAcumWk(Lang,Size,V,C1,C2,k,Lcorpora,WkAbsErrorsinCorpora,Wk,Distk):
    (gk1,hk1)=gkhk(Lang,Size,V,C1,C2,k,Distk)
    (gk2,hk2)=gkhk(Lang,Size,V,C1,C2,k+1,Distk)
    Lcorpora=np.array(Lcorpora)
    for i in range(Lcorpora.shape[0]):
        prev1=CalcD(V, gk1, hk1, Lcorpora[i])
        prev2=CalcD(V, gk2, hk2, Lcorpora[i])
        prevWk=prev1-prev2
        ErrAbs=abs((prevWk - Wk[(Lang,Size,Lcorpora[i],k)])*1.0/Wk[(Lang,Size,Lcorpora[i],k)])
        if(ErrAbs > 0):
            WkAbsErrorsinCorpora.append(ErrAbs)









    
## for the evolution of W(k) with increasing corpus size

def WkEvolutionWithC(Lang,NgranSize,TrainingCorpora,V,k,LeastCorpus,GreatestCorpus,StepsNum,OutFile):
    fo=open('W('+str(k)+',C)_'+OutFile+'.txt','w')
    C1=TrainingCorpora[0];  C2=TrainingCorpora[1]
    Distk={}; fillTrainingDistk(Distk);
    (gk1,hk1)=gkhk(Lang,NgranSize,V,C1,C2,k,Distk)
    (gk2,hk2)=gkhk(Lang,NgranSize,V,C1,C2,k+1,Distk)
    CorpusSizeIncrease= np.log(GreatestCorpus - LeastCorpus)/StepsNum; n=1;
    Corpus= LeastCorpus
    while(Corpus < GreatestCorpus):
        prev1=CalcD(V, gk1, hk1, Corpus)
        prev2=CalcD(V, gk2, hk2, Corpus)
        prevWk=prev1-prev2
        st=str(Corpus)+' '+str(prevWk)
        fo.write(st)
        fo.write('\n'); n+=1;
        Corpus = LeastCorpus+np.exp(CorpusSizeIncrease * n)
    fo.close()	

     
        
	


def CalcD(V,Ka,Kb,C):
    return V*1.0/(1 + (Kb * C)**-Ka)
    

			
def gkhk(Lang,Size,V,C1,C2,k,Distk):
    A1=V*1.0/Distk[(Lang,Size,C1,k)] - 1; A2=V*1.0/Distk[(Lang,Size,C2,k)] -1
    gk=np.log(A1/A2)/np.log(C2*1.0/C1)
    hk=(A1**(-1.0/gk))/C1
    return (gk,hk)
	
