#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 24 20:06:57 2022

@author: jfs
"""

import time
import math
import random


import numpy as np
from WkDistKBD import fillWk
from WkBD import fillTrainingWk
from WkDistKBD import fillDistk



    
def Tuning_ZipfSecond_gamma(Lang,Size,Lcorpora,Lk,p1,gammaIni,gammaFim,gammaStep):
    SqErr=99999999999;  Distk={}; fillDistk(Distk); 
    Lcorpora=np.array(Lcorpora); Lk=np.array(Lk);
    Wk={}
    fillTrainingWk(Wk)
    gamma=gammaIni
    while(gamma <= gammaFim):
        wkvec=[];
        for i in range(Lcorpora.shape[0]):
            D= Distk[(Lang,Size,Lcorpora[i],1)]
            for j in range(Lk.shape[0]):
                Obs=Wk[(Lang,Size,Lcorpora[i],Lk[j])]
                Prev= ZipfSecond_wk_C_k(D,gamma,Lcorpora[i],p1,Lk[j])
                wkvec.append(abs((Prev- Obs)/Obs))
        wkvec=np.array(wkvec)
        RMSRE=(np.mean(wkvec**2))**0.5; 
        if(RMSRE < SqErr):
            SqErr=RMSRE; Bestgamma=gamma; 
        gamma=gamma + gammaStep
    return (Bestgamma)
    



def ZipfSecond_wk(Lang,Size,TrainingCorpora,TestLcorpora,Lk,p1,gammaIni,gammaFim,gammaStep):
    print("These are the Zipf Second law W(k) prediction Errors for a Test Corpora. It may take less than 1 minute")
    print(" ")
    gamma=Tuning_ZipfSecond_gamma(Lang,Size,TrainingCorpora,Lk,p1,gammaIni,gammaFim,gammaStep)
    print("Best Gamma",gamma)
    print("")
    TestLcorpora=np.array(TestLcorpora); Lk=np.array(Lk);
    Distk={}; fillDistk(Distk); Wk={}; fillWk(Wk)
    for i in range(TestLcorpora.shape[0]):
        wkvec=[]
        D= Distk[(Lang,Size,TestLcorpora[i],1)]
        for j in range(Lk.shape[0]):
            Obs=Wk[(Lang,Size,TestLcorpora[i],Lk[j])]
            Prev= ZipfSecond_wk_C_k(D,gamma,TestLcorpora[i],p1,Lk[j])
            wkvec.append(abs((Prev- Obs)/Obs))
#            print(TestLcorpora[i],Lk[j],Prev)
        wkvec=np.array(wkvec);
        AvgErr=np.mean(wkvec);
        RMSRE=(np.mean(wkvec**2))**0.5;
        print('Error for Corpus=',TestLcorpora[i],'words:')
        print(' Average Relative Error: ',str(AvgErr * 100)+'%')
        print(' Root-Mean-Square Relative Error: ',str(RMSRE * 100)+'%')
        print(' ')           

def ZipfSecond_wk_C_k(D,gamma,C,p1,k):
    num=D * (-gamma + 1)
    den=((C*p1)**(-gamma+1) - 1)* (k**gamma)
    return num/den







#For the Price Model

def PriceForCorporaListSearchM(Lang,Size,TrainingCorporaList,TestorporaList,kList,InicialM,FinalM,StepM):
    Wk={}; fillWk(Wk); fillTrainingWk(Wk); Distk={}; fillDistk(Distk)
    M=InicialM; GlobalErr=999999
    while(M<=FinalM):
        TrainErrList=[]
        for c in range(len(TrainingCorporaList)):
            for i in range(len(kList)):
                D=Distk[(Lang,Size,TrainingCorporaList[c],1)]
                Prev=(M+1)* D * gamma(kList[i],M+2)
                Obs=Wk[(Lang,Size,TrainingCorporaList[c],kList[i])]
                TrainErrList.append(abs((Prev- Obs)/Obs))
        TrainErrList=np.array(TrainErrList)
        RMSRE=(np.mean(TrainErrList**2))**0.5
        if(GlobalErr > RMSRE):
           GlobalErr= RMSRE; BestM=M
        M=M + StepM
    print("Best M:",BestM);print()
    for c in range(len(TestorporaList)):
        Price76(Lang,Size,TestorporaList[c],kList,BestM,Wk,Distk)


def Price76(Lang,Size,Corpus,kList,M,Wk,Distk):
    ErrosAbsWkCorpus=[]; D=Distk[(Lang,Size,Corpus,1)]
    for i in range(len(kList)):
        Prev=(M+1)* D * gamma(kList[i],M+2)
        Obs=Wk[(Lang,Size,Corpus,kList[i])]
        ErrosAbsWkCorpus.append(abs((Prev- Obs)/Obs))
    ErrosAbsWkCorpus=np.array(ErrosAbsWkCorpus)
    AvgErr=np.mean(ErrosAbsWkCorpus);RMSRE=(np.mean(ErrosAbsWkCorpus**2))**0.5
    print('Error for Corpus=',Corpus,'words:')
    print('Average Relative Error:',AvgErr)
    print('Root-Mean-Square Relative Error:',RMSRE)
    print(' ')
    

def gamma(x,y):
    return incgamma(x,0) * incgamma(y,0)*1.0/incgamma(x+y,0)


import subprocess
def incgamma(a, b):
    proc = subprocess.Popen(['./incgamma', str(a), str(b)], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, error = proc.communicate()
    failed = proc.returncode
    if not failed:
        return float(output)
    else:
        raise Exception("incgamma failed: " + error)


