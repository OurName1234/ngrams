#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 30 13:31:58 2022

@author: jfs
"""
def fillTrainingCorpora(TrainingCorpora):
#for English
    TrainingCorpora[('en',1)]=(30942239, 2155599290)
    TrainingCorpora[('en',2)]=(30942238, 2155599274)
    TrainingCorpora[('en',3)]=(30942237, 2155599258)
    TrainingCorpora[('en',4)]=(30942236, 2155599242)
    TrainingCorpora[('en',5)]=(30942235, 2155599226)
    TrainingCorpora[('en',6)]=(30942234, 2155599210)
#for French
    TrainingCorpora[('fr',1)]=(201439011,1605507129)
    TrainingCorpora[('fr',2)]=(201439010,1605507121)
    TrainingCorpora[('fr',3)]=(201439009,1605507113)
    TrainingCorpora[('fr',4)]=(201439008,1605507105)
    TrainingCorpora[('fr',5)]=(201439007,1605507097)
    TrainingCorpora[('fr',6)]=(201439006,1605507089)
    
  