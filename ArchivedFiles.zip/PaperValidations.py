#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 24 20:06:57 2022

@author: jfs
"""

import time
import math
import random
import time


import numpy as np
from DistKBD import fillTrainingDistk
from WkBD import fillTrainingWk
from WkDistKBD import fillWk
from WkDistKBD import fillDistk
from Vocabulary import fillVoc
from TrainingCorpora import fillTrainingCorpora




   



	


  



# for predicting the W(k) errors (the average of the module of relative error, and the Root Mean Square of the Relative Error) for each k value.
def ErrorsByKlist(Lang,Size,V,TrainingCorpora,Testcorpora,Lk):
    Wk={}; fillWk(Wk); fillTrainingWk(Wk);
    Distk={}; fillDistk(Distk); fillTrainingDistk(Distk)
    C1=TrainingCorpora[0]; C2=TrainingCorpora[1]
    AvgVec=[]
    for i in range(len(Lk)):
        k=Lk[i]
        (AvgErr,RMSRE)=ErrorsForK(Lang,Size,V,C1,C2,k,Testcorpora,Wk,Distk)
        print('')
        print('Errors for',Lang,'language,',str(Size)+'-grams and k=',k,':')
        print(' Average Relative Error --',str(AvgErr * 100)+'%')
        print(' Root Mean Square of the Relative Error --',str(RMSRE * 100)+'%')
        AvgVec.append(AvgErr)
    AvgVec=np.array(AvgVec)
    print('')
    print('Global (full test corpora) Average Relative Error: ', str(np.mean(AvgVec) * 100)+'%')
    


def ErrorsForK(Lang,Size,V,C1,C2,k,Lcorpora,Wk,Distk):
    WkAbsErrorsinCorpora=[]
    (gk1,hk1)=gkhk(Lang,Size,V,C1,C2,k,Distk)
    (gk2,hk2)=gkhk(Lang,Size,V,C1,C2,k+1,Distk)
    Lcorpora=np.array(Lcorpora)
    for i in range(Lcorpora.shape[0]):
        prev1=CalcD(V, gk1, hk1, Lcorpora[i])
        prev2=CalcD(V, gk2, hk2, Lcorpora[i])
        prevWk=prev1-prev2
        ErrAbs=abs((prevWk - Wk[(Lang,Size,Lcorpora[i],k)])*1.0/Wk[(Lang,Size,Lcorpora[i],k)])
        if(ErrAbs > 1.0e-11):
            WkAbsErrorsinCorpora.append(ErrAbs)
    WkAbsErrorsinCorpora=np.array(WkAbsErrorsinCorpora)
    AvgErr=np.mean(WkAbsErrorsinCorpora); RMSRE=(np.mean(WkAbsErrorsinCorpora**2))**0.5
    return (AvgErr,RMSRE)





def ErrForCorporaList(Lang,NgramSize,Voc,Trainingcorpora,Lk,Testcorpora):
    Wk={}; fillWk(Wk); fillTrainingWk(Wk)
    Distk={}; fillDistk(Distk); fillTrainingDistk(Distk)
    AvgVec=[]
    for i in range(len(Testcorpora)):
        Err= ErrCorpus(Lang,NgramSize,Voc,Trainingcorpora,Lk,Testcorpora[i],Wk,Distk)
        AvgVec.append(Err)
    AvgVec=np.array(AvgVec)
    print('')
    print('Global (full corpora) Average Error: ', str(np.mean(AvgVec) * 100)+'%')
    
    
#Errors by corpus 
def ErrCorpus(Lang,Size,V,Trainingcorpora,Lk1,C,Wk,Distk):
    ErrosAbsWkCorpus=[];C11=Trainingcorpora[0]; C21=Trainingcorpora[1]
    for i in range(len(Lk1)):
        k=Lk1[i]
        (gk1,hk1)=gkhk(Lang,Size,V,C11,C21,k,Distk)
        (gk2,hk2)=gkhk(Lang,Size,V,C11,C21,k+1,Distk)
        prev1=CalcD(V, gk1, hk1, C)
        prev2=CalcD(V, gk2, hk2, C)
        prevWk=prev1-prev2
        ErrAbs=abs((prevWk - Wk[(Lang,Size,C,k)])*1.0/Wk[(Lang,Size,C,k)])
        if(ErrAbs > 1.0e-11):
            ErrosAbsWkCorpus.append(ErrAbs)
    ErrosAbsWkCorpus=np.array(ErrosAbsWkCorpus)
    AvgErr=np.mean(ErrosAbsWkCorpus); RMSRE=(np.mean(ErrosAbsWkCorpus**2))**0.5
    print('Error for Corpus=',C,':')
    print('Average Relative Error: ',str(AvgErr * 100)+'%')
    print('Root-Mean-Square Relative Error: ',str(RMSRE * 100)+'%')
    print(' ')
    return AvgErr




        
#for writing the relative errors in a file for ploting log(w(k)) vs log(k) of a corpus even for in the non monotonic k zone

def PlotWkvsKCorpus(Lang,NgramSize,Voc,TrainingCorpus1,TrainingCorpus2,MaxK,CorpusSize,OutPutFileSuffix):
    fo=open('WkVsk_'+OutPutFileSuffix+'.txt','w')
    Wk={}; fillWk(Wk); fillTrainingWk(Wk); Distk={}; fillDistk(Distk); 
    fillTrainingDistk(Distk); AvgVec=[]
    ErrosAbsWkCorpus=[]
    k=1
    while(k <= MaxK):
        (gk1,hk1)=gkhk(Lang,NgramSize,Voc,TrainingCorpus1,TrainingCorpus2,k,Distk)
        (gk2,hk2)=gkhk(Lang,NgramSize,Voc,TrainingCorpus1,TrainingCorpus2,k+1,Distk)
        prev1=CalcD(Voc, gk1, hk1, CorpusSize)
        prev2=CalcD(Voc, gk2, hk2, CorpusSize)
        prevWk=prev1-prev2
        st=str(k)+' '+str(prevWk)
        fo.write(st)
        fo.write('\n')
        k=k+1
    fo.close()
	


def CalcD(V,Ka,Kb,C):
    return V*1.0/(1 + (Kb * C)**-Ka)
    

			
def gkhk(Lang,Size,V,C1,C2,k,Distk):
    A1=V*1.0/Distk[(Lang,Size,C1,k)] - 1; A2=V*1.0/Distk[(Lang,Size,C2,k)] -1
    gk=np.log(A1/A2)/np.log(C2*1.0/C1)
    hk=(A1**(-1.0/gk))/C1
    return (gk,hk)
	
