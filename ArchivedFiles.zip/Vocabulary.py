#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 30 18:01:25 2022

@author: jfs
"""

#These are the values that correspond to the sizes of vocabularies estimated by
#python program EstimateVocabularySize(Lang,Size,Vini,Vfin,Vstep,Trainingcorpora,Lk)
# in file ModeloFinal.py. Vocabularies entries are for each (Language,n-gram size) pair.

def fillVoc(Voc):
#for English
    Voc[('en',1)]=9.84e8
    Voc[('en',2)]=8.77e10
    Voc[('en',3)]=1.1e11
    Voc[('en',4)]=2.98e11
    Voc[('en',5)]=1.25e12
    Voc[('en',6)]=1.06e13
#for French
    Voc[('fr',1)]=3.28e8
    Voc[('fr',2)]=1.13e9
    Voc[('fr',3)]=1.81e9
    Voc[('fr',4)]=7.32e9
    Voc[('fr',5)]=4.58e10
    Voc[('fr',6)]=3.58e11  

   
   
