#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 22 12:42:37 2024

@author: jfs
"""

import time
import math
import random
import time
import numpy as np

from Def_DistByLangNandK import ValidationAndTestingDistkBD 

from Def_ConstantsAndGlobalVars import KSETSIZE, KMIN, KMAX, WKDEV, CONFIDLEVEL, ENOUGH_V_ERROR
from Def_ConstantsAndGlobalVars import MINWKDEV, MAXWKDEV, STEPWKDEV, MINCONFIDLEVEL, MAXCONFIDLEVEL, STEPCONFIDLEVEL, GREATESTTWOPOWER, MINAPPLICATIONK, GREATESTKBEFOREJUMP
from Def_ConstantsAndGlobalVars import VocaburaryBDFileName, SplineCoefsBDFileName, ValidationKThresholdsBdFileName, HIGHESTERROR, MAJORMONONONYK
from Def_ValidationCorporaSizes import ValidationCorporaSizesList, ConstParmCorpIndex

from Def_monotony import locConfidence
from scipy.interpolate import splrep, splev
from scipy.optimize import differential_evolution
from scipy.interpolate import SmoothBivariateSpline
import pickle
from scipy.interpolate import UnivariateSpline
from mpmath import mp




def FindParametersCrossVal(Lang,NgramSize,Vi,Vf,Vs,InpercG,EnpercG,NstpG,InpercH,EnpercH,NstpH,Model="DepParms"):
    print("It may take some minutes")
    Vi=int(Vi); Vf=int(Vf); Vs=int(Vs)
    ValidCorporaList={}
    ValidationCorporaSizesList(ValidCorporaList); 
    ValidCorpora=ValidCorporaList[(Lang,NgramSize)]
    ValidCorpora=sorted(ValidCorpora)
    k_threshold=locConfidenceKforDkCorpora(Lang,NgramSize,ValidCorpora)
    print("k_thresold for training corpora: ",k_threshold)
    with open(ValidationKThresholdsBdFileName, 'a') as file:
        st="    "+"KThreshold[("+"'"+str(Lang)+"'"+","+str(NgramSize)+")]="+str(k_threshold)
        file.write(st+"\n")
        file.close()
    GreatestK= max(min(k_threshold,KMAX),GREATESTKBEFOREJUMP)
    BdForHkandDk={}
    (BestV,DicGH,Distk) =ValidationForTuningGkAndHkOfC(Lang,NgramSize,Vi,Vf,Vs,InpercG,EnpercG,NstpG,InpercH,EnpercH,NstpH,KMIN,GreatestK,ValidCorpora,Model)
    TranslateToSoftSplinesCrossVal(Lang,NgramSize,ValidCorpora[:-1],DicGH,BestV,Distk,Model)
    with open(VocaburaryBDFileName,'a') as file:
        st="    "+"Voc[("+"'"+str(Lang)+"'"+","+str(NgramSize)+")]="+str(BestV)
        file.write(st+"\n")
        file.close()
    
          
        

def TranslateToSoftSplinesCrossVal(Lang,NgramSize,ValidCorpora,DicGH,V,Distk,Model):
    DicSplineGH={}
    GSpairs=[((Gg,Gs/10),(Hg,Hs/10)) for Gg in range(3,6) for Gs in range(0,70,5) for Hg in range(3,6) for Hs in range(0,70,5)  ]
    for kapa in DicGH:
        BestGHError= HIGHESTERROR; 
        for ((Gg,Gs),(Hg,Hs)) in GSpairs:
            (Gvals,preHvals)=DicGH[kapa]
            TrinValG_Combinations=TrainValidCombinations(ValidCorpora,Gvals,preHvals)
            SKRgsErr=CombGHErr(Lang,NgramSize,kapa,TrinValG_Combinations,Gg,Gs,Hg,Hs,V,Distk)
            if (BestGHError > SKRgsErr):
                BestGHError= SKRgsErr; BestGgs=(Gg,Gs);BestHgs= (Hg,Hs)
        splineG= UnivariateSpline(ValidCorpora, Gvals,s=BestGgs[1],k=BestGgs[0])
        Hvals= -np.log(preHvals)
        splineH= UnivariateSpline(ValidCorpora, Hvals, s=BestHgs[1],k=BestHgs[0])
        DicSplineGH[kapa]=(splineG,splineH)
    SaveSoftGH(Lang,NgramSize,DicSplineGH,Model)        
            
            

def CombGHErr(Lang,NgramSize,kapa,TrinValG_Combinations,Gg,Gs,Hg,Hs,V,Distk):
    CombError=[]
    for (TrCorp, TrGvals, TrHvals, ValidCorpus) in TrinValG_Combinations:
        splineG=UnivariateSpline(TrCorp, TrGvals,s=Gs,k=Gg )
        Hvals= -np.log(TrHvals)
        splineH= UnivariateSpline(TrCorp, Hvals, s=Hs,k=Hg)
        Err=ErrForDkForTestCorpusVal(Lang,NgramSize,ValidCorpus,kapa,splineG,splineH,V,Distk)
        CombError.append(Err)
    CombError=np.array(CombError)
    return np.mean(CombError**2)**0.5    
        
def ErrForDkForTestCorpusVal(Lang,NgramSize,C,k,splineG,splineH,V,Distk):
    PredDk=PredictDkVal(Lang,NgramSize,C,k,splineG,splineH,V,Distk)
    EmpDk=Distk[(Lang,NgramSize,C,k)]
    return abs((PredDk - EmpDk)/EmpDk)


   
def PredictDkVal(Lang,NgramSize,C,k,splineG,splineH,V,Distk):
    Gpred = splineG(C)
    Hpred = np.exp(-1 * splineH(C))
    return CalcDVal(V,Gpred,Hpred,C)
    

def CalcDVal(V,g,h,C):
    return V*1.0/(1 + (h * C)**-g)


def TrainValidCombinations(V1,V2,V3):
    combinations=[]
    for i in range(1, len(V1) - 1):  
        V1train = V1[:i] + V1[i+1:]
        V2train = V2[:i] + V2[i+1:]
        V3train = V3[:i] + V3[i+1:]
        deleted_element = V1[i]
        combinations.append((V1train, V2train, V3train, deleted_element))
    return combinations

      
def SaveSoftGH(Lang, NgramSize,DicSplineGH,Model):
    if(Model == "DepParms"):
        SplineFile='Def_smooth_spline_results.pkl'
    else:
        SplineFile='Def_smooth_spline_results_const.pkl'
    try:
        with open(SplineFile, 'rb') as f:
            spline_results = pickle.load(f)
    except FileNotFoundError:
        spline_results = {}
    spline_results[(Lang, NgramSize)] = DicSplineGH
# Save the updated splines back to the file
    with open(SplineFile, 'wb') as f:
        pickle.dump(spline_results, f)
    
    




def ValidationForTuningGkAndHkOfC(Lang,Size,Vi,Vf,Vs,InpercG,EnpercG,NstpG,InpercH,EnpercH,NstpH,Kmin,GreatestK,CorporaListSorted,Model):
    Distk={}; PreBestG_H_V={};
    ValidationAndTestingDistkBD(Distk);
    C1=CorporaListSorted[0]; C2=CorporaListSorted[-1];
    BestMasterError= HIGHESTERROR; 
    ListOfk= [k for k in range(1, GreatestK + 1)] + [2**p for p in range((GreatestK ).bit_length(), GREATESTTWOPOWER +1)]
    Erant=99999 ; VAnt= Vi- Vs
    V=Vi
    while(V <= Vf and BestMasterError >=ENOUGH_V_ERROR):
        print("Processing for the hypothetical vocabulary size: ",V)
        VMasterError=[]; k = Kmin; VError=[]
        for k in ListOfk:
            (gk1,hk1)=gkhk(Lang,Size,V,C1,C2,k,Distk)
            MinRMSREfork =HIGHESTERROR; Errant=1
            gstep = gk1 * (EnpercG - InpercG)/NstpG; gk=gk1* InpercG;
            hstep = hk1 * (EnpercH - InpercH)/NstpH;
            while ( gk <= EnpercG * gk1):
                hk=hk1* InpercH; 
                while( hk <=  EnpercH * hk1):
                    ErrTrpl=[]
                    for C in CorporaListSorted:
                        ErrTrpl.append(abs((CalcD(V,gk,hk,C)- Distk[(Lang,Size,C,k)])/Distk[(Lang,Size,C,k)]))
                    ErrTrpl=np.array(ErrTrpl)
                    RMSRE=(np.mean(ErrTrpl**2))**0.5
                    if (RMSRE < MinRMSREfork):
                        MinRMSREfork = RMSRE; 
                    if(RMSRE < Errant):
                        hk = hk + hstep * 0.8
                    else:
                        hk = hk + hstep * 1.2
                    Errant= RMSRE
                gk=gk + gstep    
            VMasterError.append(MinRMSREfork);  
        VMasterError=np.array(VMasterError)    
        RMSRE_of_RMSRE= (np.mean(VMasterError**2))**0.5; 
        if(RMSRE_of_RMSRE < BestMasterError):
            BestMasterError = RMSRE_of_RMSRE; BestV=V;
        V = V + Vs
    print("Best Vocabulary Size:", BestV)
    DicGH=FineTunningGH(Lang,Size,BestV,ListOfk, CorporaListSorted,Distk,Model)   
    return (BestV,DicGH,Distk)


def FineTunningGH(Lang,Size,BestV,ListOfk, CorporaListSorted,Disk,Model):
    DicGH={}
    if(Model =="DepParms"):
        for k in ListOfk:
            (Gk,Hk)=TuneGHforK(Lang,Size,BestV,k,CorporaListSorted,Disk)
            DicGH[k]=(Gk,Hk)
        return DicGH
    else:
        Anchors={}
        ConstParmCorpIndex(Anchors)
        (Al,Ar)=Anchors[Lang][Size -1]
        for k in ListOfk:
            (Gk,Hk)=ConstTuneGHforK(Lang,Size,BestV,k,CorporaListSorted,Disk,Al,Ar)
            DicGH[k]=(Gk,Hk)
        return DicGH
        

    

def TuneGHforK(Lang,Size,V,k,CorporaListSorted,Distk):
    Gvec=[]; Hvec=[]; C2=CorporaListSorted[-1]
    for i in range(len(CorporaListSorted)-1):
        C1=CorporaListSorted[i]
        (gk1,hk1)=gkhk(Lang,Size,V,C1,C2,k,Distk)
        Gvec.append(gk1); Hvec.append(hk1)
    return (Gvec,Hvec)


#for const model
def ConstTuneGHforK(Lang,Size,V,k,CorporaListSorted,Distk,Al,Ar):
    Gvec=[]; Hvec=[]; C2=CorporaListSorted[Ar]
    for i in range(len(CorporaListSorted)-1):
        C1=CorporaListSorted[Al]
        (gk1,hk1)=gkhk(Lang,Size,V,C1,C2,k,Distk)
        Gvec.append(gk1); Hvec.append(hk1)
    return (Gvec,Hvec)



def locConfidenceKforDkCorpora(Lang,n,Lc):
    MaxCDKFactor=1
    Distk = {}
    ValidationAndTestingDistkBD(Distk);
    ConfLev_Deviation_Pairs=[(ConfLev/1000,Deviation/1000) for ConfLev in range(int(MINCONFIDLEVEL * 1000),int(MAXCONFIDLEVEL * 1000)+int(STEPCONFIDLEVEL * 1000),int(STEPCONFIDLEVEL * 1000)) 
                             for Deviation in range(int(MINWKDEV * 1000),int(MAXWKDEV * 1000)+int(STEPWKDEV * 1000),int(STEPWKDEV * 1000)) ]
    k_max=0
    for (ConfidenceLevel,Deviation) in  ConfLev_Deviation_Pairs:
        CorpusMonotonyK={}
        for C in Lc:
            CorpusMonotonyK[(Lang,n,C)]= locConfidence(Lang,n,C,Distk,Deviation,ConfidenceLevel)
        k_threshold=min(CorpusMonotonyK.values())
        k_max=max(k_max,k_threshold)
        if(k_threshold >=MINAPPLICATIONK):
            CDKFactor=ConfDevKmaxFactor(ConfidenceLevel,Deviation,k_threshold)
            if (CDKFactor > MaxCDKFactor):
                MaxCDKFactor= CDKFactor; LangNgKthreshold = k_threshold
    if (MaxCDKFactor==1):
        LangNgKthreshold=k_max
    return LangNgKthreshold


def ConfDevKmaxFactor(Conf,Dev,K):
    return ((Conf/Dev)*K)
	
def CalcD(V,Ka,Kb,C):
    return V*1.0/(1 + (Kb * C)**-Ka)
    

			
def gkhk(Lang,Size,V,C1,C2,k,Distk):
    A1=V*1.0/Distk[(Lang,Size,C1,k)] - 1; A2=V*1.0/Distk[(Lang,Size,C2,k)] -1
    gk=np.log(A1/A2)/np.log(C2*1.0/C1)
    hk=(A1**(-1.0/gk))/C1
    return (gk,hk)
	






         
    
    
    
    

