#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 24 20:06:57 2022

@author: jfs
"""

import time
import math
import random
import time


import numpy as np
from BaseLineModelDistKBD import fillTrainingDistk






   





def WkReturn(k,Corpus,Lang,NgranSize):
    from BaseLineModelVocabulary import fillVoc
    from BaseLineModelTrainingCorpora import fillTrainingCorpora
    TrainingCorpora={}; fillTrainingCorpora(TrainingCorpora)
    (C1,C2)=TrainingCorpora[(Lang,NgranSize)]
    Voc={}; fillVoc(Voc)
    V=Voc[(Lang,NgranSize)]
    Distk={}; fillTrainingDistk(Distk);
    (gk1,hk1)=gkhk(Lang,NgranSize,V,C1,C2,k,Distk)
    (gk2,hk2)=gkhk(Lang,NgranSize,V,C1,C2,k+1,Distk)
    prevDk=CalcD(V, gk1, hk1, Corpus)
    prevDkplus1=CalcD(V, gk2, hk2, Corpus)
    return prevDk-prevDkplus1

  	        
def DkReturn(k,Corpus,Lang,NgranSize):
    from BaseLineModelVocabulary import fillVoc
    from BaseLineModelTrainingCorpora import fillTrainingCorpora
    TrainingCorpora={}; fillTrainingCorpora(TrainingCorpora)
    (C1,C2)=TrainingCorpora[(Lang,NgranSize)]
    Voc={}; fillVoc(Voc)
    V=Voc[(Lang,NgranSize)]
    Distk={}; fillTrainingDistk(Distk);
    (gk1,hk1)=gkhk(Lang,NgranSize,V,C1,C2,k,Distk)
    return CalcD(V, gk1, hk1, Corpus)
    



def AntModTestDkActualKbyK(Lang, NgramSize,CorporaList=[]):
    from Def_ConstantsAndGlobalVars import GREATESTTWOPOWER, GREATESTKBEFOREJUMP
    ListOfk= [k for k in range(1, GREATESTKBEFOREJUMP + 1)] 
    GlobErr=[]
    for k in ListOfk:
        GlobErr.append(AntModTestDkActualK(Lang, NgramSize, k,CorporaList))
    print("Global Error",np.mean(GlobErr))
    

def AntModTestDkActualK(Lang, NgramSize, k,CorporaList=[]):
    from Def_TestingCorporaSizes import TestingCorporaSizesList
    from Def_DistByLangNandK import ValidationAndTestingDistkBD
    if (CorporaList == []):
        TestCorpora={}
        DistkActual={}
        TestingCorporaSizesList(TestCorpora)
        ValidationAndTestingDistkBD(DistkActual)
        CorporaList = TestCorpora[(Lang, NgramSize)]
        verr=[]
        for c in CorporaList:
            d=DkReturn(k,c,Lang,NgramSize)
            demp= DistkActual[(Lang, NgramSize,c,k)]
            err=abs((d - demp)/ demp)
            verr.append(err)
        verr=np.array(verr)
        AvgErr=np.mean(verr); RMSRE=(np.mean(verr**2))**0.5
    print("Dk average and square Errors for k,Lang, Ngram: ",k,Lang, NgramSize,":",AvgErr,RMSRE)
    return AvgErr





def AntModTestWkActualKbyK(Lang, NgramSize,CorporaList=[]):
    from Def_ConstantsAndGlobalVars import GREATESTTWOPOWER, GREATESTKBEFOREJUMP
    ListOfk= [k for k in range(1, GREATESTKBEFOREJUMP )] 
    GlobErr=[]
    for k in ListOfk:
        GlobErr.append(AntModTestWkActualK(Lang, NgramSize, k,CorporaList))
    print("Global Error",np.mean(GlobErr))
    

def AntModTestWkActualK(Lang, NgramSize, k,CorporaList=[]):
    from Def_TestingCorporaSizes import TestingCorporaSizesList
    from Def_DistByLangNandK import ValidationAndTestingDistkBD
    if (CorporaList == []):
        TestCorpora={}
        DistkActual={}
        TestingCorporaSizesList(TestCorpora)
        ValidationAndTestingDistkBD(DistkActual)
        CorporaList = TestCorpora[(Lang, NgramSize)]
        verr=[]
        for c in CorporaList:
            w=WkReturn(k,c,Lang,NgramSize)
            demp= DistkActual[(Lang, NgramSize,c,k)]
            dnextemp= DistkActual[(Lang, NgramSize,c,k+1)]
            wemp= demp - dnextemp
            err=abs((w - wemp)/ wemp)
            verr.append(err)
        verr=np.array(verr)
        AvgErr=np.mean(verr); RMSRE=(np.mean(verr**2))**0.5
    print("Wk average and square Errors for k,Lang, Ngram: ",k,Lang, NgramSize,":",AvgErr,RMSRE)
    return AvgErr






def AntModTestDkActualC(Lang, NgramSize, CorporaList=[]):
    from Def_TestingCorporaSizes import TestingCorporaSizesList
    from Def_DistByLangNandK import ValidationAndTestingDistkBD
    from Def_ConstantsAndGlobalVars import GREATESTTWOPOWER, GREATESTKBEFOREJUMP
    from Def_KThresolds import KThresholdsBD
    GREATESTTWOPOWER=4
    KTBd={}
    KThresholdsBD(KTBd)
    k_threshold=KTBd[(Lang, NgramSize)]
    ListOfk= [k for k in range(1, GREATESTKBEFOREJUMP + 1)] 
    if (CorporaList == []):   
        TestCorpora={}
        DistkActual={}
        TestingCorporaSizesList(TestCorpora)
        ValidationAndTestingDistkBD(DistkActual)
        CorporaList = TestCorpora[(Lang, NgramSize)]
        GlobErr=[]
        for c in CorporaList:
            verr=[]
            for k in ListOfk:
                d=DkReturn(k,c,Lang,NgramSize)
                demp= DistkActual[(Lang, NgramSize,c,k)]
                err=abs((d - demp)/ demp)
                verr.append(err)
            verr=np.array(verr)
            AvgErr=np.mean(verr); RMSRE=(np.mean(verr**2))**0.5
            GlobErr.append(AvgErr)
            print("Dk average and square Errors for c,Lang, Ngram: ",c,Lang, NgramSize,":",AvgErr,RMSRE)
        print("Global Error :",np.mean(GlobErr))
            
    

def AntModTestWkActualC(Lang, NgramSize, CorporaList=[]):
    import sys
    sys.path.append('/Users/jfs/backup/artigo/tese/extractorparalelo/novos/modeloacum/semfit/polinomio')
    from Def_TestingCorporaSizes import TestingCorporaSizesList
    from Def_DistByLangNandK import ValidationAndTestingDistkBD
    from Def_ConstantsAndGlobalVars import GREATESTTWOPOWER, GREATESTKBEFOREJUMP
    from Def_KThresolds import KThresholdsBD
    GREATESTTWOPOWER=4
    KTBd={}
    KThresholdsBD(KTBd)
    k_threshold=KTBd[(Lang, NgramSize)]
    ListOfk= [k for k in range(1, GREATESTKBEFOREJUMP)] 
    if (CorporaList == []):   
        TestCorpora={}
        DistkActual={}
        TestingCorporaSizesList(TestCorpora)
        ValidationAndTestingDistkBD(DistkActual)
        CorporaList = TestCorpora[(Lang, NgramSize)]
        GlobErr=[]
        for c in CorporaList:
            verr=[]
            for k in ListOfk:
                w=WkReturn(k,c,Lang,NgramSize)
                demp= DistkActual[(Lang, NgramSize,c,k)]
                dnextemp= DistkActual[(Lang, NgramSize,c,k+1)]
                wemp=demp - dnextemp
                err=abs((w - wemp)/ wemp)
                verr.append(err)
            verr=np.array(verr)
            AvgErr=np.mean(verr); RMSRE=(np.mean(verr**2))**0.5
            GlobErr.append(AvgErr)
            print("Wk average and square Errors for c,Lang, Ngram: ",c,Lang, NgramSize,":",AvgErr,RMSRE)
        print("Global Error :",np.mean(GlobErr))
       


       


	











    

     
        
	


def CalcD(V,Ka,Kb,C):
    return V*1.0/(1 + (Kb * C)**-Ka)
    

			
def gkhk(Lang,Size,V,C1,C2,k,Distk):
    A1=V*1.0/Distk[(Lang,Size,C1,k)] - 1; A2=V*1.0/Distk[(Lang,Size,C2,k)] -1
    gk=np.log(A1/A2)/np.log(C2*1.0/C1)
    hk=(A1**(-1.0/gk))/C1
    return (gk,hk)
	
