#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 26 20:31:07 2024

@author: jfs
"""



import time
import math
import random
import numpy as np
from mpmath import mp
from scipy.interpolate import splrep,splev
from Def_DistByLangNandK import ValidationAndTestingDistkBD
from Def_TestingCorporaSizes import TestingCorporaSizesList
from Def_ValidationCorporaSizes import ValidationCorporaSizesList
from Def_monotony import locConfidence
from Def_ConstantsAndGlobalVars import GREATESTTWOPOWER, POSFORSCALE, GREATESTKBEFOREJUMP
from Def_Vocabulary import VocBD
from Def_KThresolds import KThresholdsBD
from scipy.interpolate import SmoothBivariateSpline
import pickle

# Function to load splines from the file
def LoadSoftGH(Lang, NgramSize,Model):
    if(Model == "DepParms"):
        SplineFile='Def_smooth_spline_results.pkl'
    else:
        SplineFile='Def_smooth_spline_results_const.pkl'
    try:
        with open(SplineFile, 'rb') as f:
            spline_results = pickle.load(f)
        if (Lang, NgramSize) in spline_results:
            return spline_results[(Lang, NgramSize)]
        else:
            raise KeyError(f"Splines for Lang={Lang}, NgramSize={NgramSize} not found.")
    except FileNotFoundError:
        raise FileNotFoundError(f"The file {SplineFile} does not exist.")





def EachDkRelErrorTroughTestCorporaWithScale(Lang,NgramSize,Model="DepParms",TestCorpora=[]):
    ValidCorporaList={}
    ValidationCorporaSizesList(ValidCorporaList); 
    ValidCorpora=ValidCorporaList[(Lang,NgramSize)]
    ValidCorpora=sorted(ValidCorpora)
    GHCorpusForScale=ValidCorpora[POSFORSCALE]
    GreatestTrainCorpus=ValidCorpora[-2]
    #
    KTBd={}; KThresholdsBD(KTBd)
    k_threshold=KTBd[(Lang,NgramSize)]
    SplineCoefs={}; DicGHofK=LoadSoftGH(Lang, NgramSize,Model)
    Distk={}; ValidationAndTestingDistkBD(Distk)
    TestCorpusMonotonyK={}
    if(TestCorpora==[]):
        TestCorporaDic={}; 
        TestingCorporaSizesList(TestCorporaDic); 
        TestCorpora=TestCorporaDic[(Lang,NgramSize)]
    Voc={};VocBD(Voc)
    V=Voc[(Lang,NgramSize)]
    #
    ListOfk= [k for k in range(1, GREATESTKBEFOREJUMP + 1)] + [2**p for p in range((GREATESTKBEFOREJUMP ).bit_length(), GREATESTTWOPOWER +1)]
    GlobErr=[]; GlobSqRerr=[]
    for k in ListOfk:
        ErrsVec=[]
        for C in TestCorpora:
            Err= ErrForDkForTestCorpusScale(Lang,NgramSize,GreatestTrainCorpus,GHCorpusForScale,C,k,DicGHofK,V,Distk)
            ErrsVec.append(Err)
        ErrsVec=np.array(ErrsVec)
        AvgErr=np.mean(ErrsVec); SqErr=np.mean(ErrsVec**2)**0.5
        print("Prediction of Relative Errors and Mean Square Root of Relative Errors for Dk, k >=",k,":", AvgErr, SqErr)
        GlobErr.append(AvgErr); GlobSqRerr.append(SqErr)
    GlobErr=np.array(GlobErr); GlobSqRerr=np.array(GlobSqRerr)
    print("Global Averages for Relative Errors for Dk:",np.mean(GlobErr))



def EachWkRelErrorTroughTestCorporaWithScale(Lang,NgramSize,Model="DepParms",TestCorpora=[]):
    ValidCorporaList={}
    ValidationCorporaSizesList(ValidCorporaList); 
    ValidCorpora=ValidCorporaList[(Lang,NgramSize)]
    ValidCorpora=sorted(ValidCorpora)
    GHCorpusForScale=ValidCorpora[POSFORSCALE]
    GreatestTrainCorpus=ValidCorpora[-2]
    #
    KTBd={}; KThresholdsBD(KTBd)
    k_threshold=KTBd[(Lang,NgramSize)]
    SplineCoefs={}; DicGHofK=LoadSoftGH(Lang, NgramSize,Model)
    Distk={}; ValidationAndTestingDistkBD(Distk)
    TestCorpusMonotonyK={}
    if(TestCorpora==[]):
        TestCorporaDic={}; 
        TestingCorporaSizesList(TestCorporaDic); 
        TestCorpora=TestCorporaDic[(Lang,NgramSize)]
    Voc={};VocBD(Voc)
    V=Voc[(Lang,NgramSize)]
    ListOfk= [k for k in range(1, k_threshold)]
    GlobErr=[]; GlobSqRerr=[]
    for k in ListOfk:
        ErrsVec=[]
        for C in TestCorpora:
            Err= ErrForWkForTestCorpusScale(Lang,NgramSize,GreatestTrainCorpus,GHCorpusForScale,C,k,DicGHofK,V,Distk)
            ErrsVec.append(Err)
        ErrsVec=np.array(ErrsVec)
        AvgErr=np.mean(ErrsVec); SqErr=np.mean(ErrsVec**2)**0.5
        print("Prediction of Relative Errors and Mean Square Root of Relative Errors for Wk, k =",k,":", AvgErr,SqErr)
        GlobErr.append(AvgErr); GlobSqRerr.append(SqErr)
    GlobErr=np.array(GlobErr); GlobSqRerr=np.array(GlobSqRerr)
    print("Global Averages for Relative Errors, for Wk:",np.mean(GlobErr))


def AvgDkRelErrorForEachTestCorpusWithScale(Lang,NgramSize,Model="DepParms",TestCorpora=[]):
    ValidCorporaList={}
    ValidationCorporaSizesList(ValidCorporaList); 
    ValidCorpora=ValidCorporaList[(Lang,NgramSize)]
    ValidCorpora=sorted(ValidCorpora)
    GHCorpusForScale=ValidCorpora[POSFORSCALE]
    GreatestTrainCorpus=ValidCorpora[-2]
    KTBd={}; KThresholdsBD(KTBd)
    k_threshold=KTBd[(Lang,NgramSize)]
    SplineCoefs={}; DicGHofK=LoadSoftGH(Lang, NgramSize,Model)
    Distk={}; ValidationAndTestingDistkBD(Distk)
    TestCorpusMonotonyK={}
    if(TestCorpora==[]):
        TestCorporaDic={}; 
        TestingCorporaSizesList(TestCorporaDic); 
        TestCorpora=TestCorporaDic[(Lang,NgramSize)]
    Voc={};VocBD(Voc)
    V=Voc[(Lang,NgramSize)]
    GlobErr=[]; GlobSqRerr=[]
    for C in TestCorpora:
        ErrsVec=[]
        ListOfk= [k for k in range(1, GREATESTKBEFOREJUMP + 1)] + [2**p for p in range((GREATESTKBEFOREJUMP ).bit_length(), GREATESTTWOPOWER +1)]
        for k in ListOfk:
            Err= ErrForDkForTestCorpusScale(Lang,NgramSize,GreatestTrainCorpus,GHCorpusForScale,C,k,DicGHofK,V,Distk)
            ErrsVec.append(Err)
        ErrsVec=np.array(ErrsVec)
        AvgErr=np.mean(ErrsVec); SqErr=np.mean(ErrsVec**2)**0.5
        print("Prediction of Relative Errors and Mean Square Root of Dk Relative Errors for C =",C,":", AvgErr,SqErr)
        GlobErr.append(AvgErr); GlobSqRerr.append(SqErr)
    GlobErr=np.array(GlobErr); GlobSqRerr=np.array(GlobSqRerr)
    print("Global Averages for Relative Errors, for C:",np.mean(GlobErr))



def AvgWkRelErrorForEachTestCorpusWithScale(Lang,NgramSize,Model="DepParms",TestCorpora=[]):
    ValidCorporaList={}
    ValidationCorporaSizesList(ValidCorporaList); 
    ValidCorpora=ValidCorporaList[(Lang,NgramSize)]
    ValidCorpora=sorted(ValidCorpora)
    GHCorpusForScale=ValidCorpora[POSFORSCALE]
    GreatestTrainCorpus=ValidCorpora[-2]
    KTBd={}; KThresholdsBD(KTBd)
    k_threshold=KTBd[(Lang,NgramSize)]
    SplineCoefs={}; DicGHofK=LoadSoftGH(Lang, NgramSize,Model)
    Distk={}; ValidationAndTestingDistkBD(Distk)
    TestCorpusMonotonyK={}
    if(TestCorpora==[]):
        TestCorporaDic={}; 
        TestingCorporaSizesList(TestCorporaDic); 
        TestCorpora=TestCorporaDic[(Lang,NgramSize)]
    Voc={};VocBD(Voc)
    V=Voc[(Lang,NgramSize)]
    GlobErr=[]; GlobSqRerr=[]
    for C in TestCorpora:
        ErrsVec=[]
        ListOfk= [k for k in range(1, k_threshold)]
        for k in ListOfk:
            Err=ErrForWkForTestCorpusScale(Lang,NgramSize,GreatestTrainCorpus,GHCorpusForScale,C,k,DicGHofK,V,Distk)
            ErrsVec.append(Err)
        ErrsVec=np.array(ErrsVec)
        AvgErr=np.mean(ErrsVec); SqErr=np.mean(ErrsVec**2)**0.5
        print("Prediction of Relative Errors and Mean Square Root of wk Relative Errors for C =",C,":", AvgErr,SqErr)
        GlobErr.append(AvgErr); GlobSqRerr.append(SqErr)
    GlobErr=np.array(GlobErr); GlobSqRerr=np.array(GlobSqRerr)
    print("Global Averages for Relative Errors, for C:",np.mean(GlobErr))


            

def ErrForWkForTestCorpusScale(Lang,NgramSize,GreatestTrainCorpus,GHCorpusForScale,C,k,DicGHofK,V,Distk):
    PredDk=PredictDkScale(Lang,NgramSize,GreatestTrainCorpus,GHCorpusForScale,C,k,DicGHofK,V,Distk)
    PredDNextk=PredictDkScale(Lang,NgramSize,GreatestTrainCorpus,GHCorpusForScale,C,k+1,DicGHofK,V,Distk)
    PredWk= PredDk - PredDNextk
    EmpWk=Distk[(Lang,NgramSize,C,k)] - Distk[(Lang,NgramSize,C,k+1)]
    return abs((PredWk - EmpWk)/EmpWk)

def PredictDkScale(Lang,NgramSize,GreatestTrainCorpus,CorpusForScale,C,k,DicGHofK,V,Distk):
    if(C > GreatestTrainCorpus ):
        (PredGk,PredHk)=GetGH(Lang,NgramSize,DicGHofK,k,CorpusForScale )
    else:
        (PredGk,PredHk)=GetGH(Lang,NgramSize,DicGHofK,k,C)
    return CalcD(V,PredGk,PredHk,C)


def ErrForDkForTestCorpusScale(Lang,NgramSize,GreatestTrainCorpus,GHCorpusForScale,C,k,DicGHofK,V,Distk):
    PredDk=PredictDkScale(Lang,NgramSize,GreatestTrainCorpus,GHCorpusForScale,C,k,DicGHofK,V,Distk)
    EmpDk=Distk[(Lang,NgramSize,C,k)]
    return abs((PredDk - EmpDk)/EmpDk)
    
    
def GetGH(Lang,NgramSize,DicGHofK,k,CorpusSize):
    (SplineG,SplineH)=DicGHofK[k]
    Gpred = SplineG(CorpusSize)
    Hpred = np.exp(-1 * SplineH( CorpusSize))
    return (Gpred,Hpred)



def CalcD(V,Ka,Kb,C):
    return V*1.0/(1 + (Kb * C)**-Ka)



           
 
        

    

			

	
