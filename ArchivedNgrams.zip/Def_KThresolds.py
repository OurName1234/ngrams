   
def KThresholdsBD(KThreshold):
    pass
       
    KThreshold[('en',1)]=10
    KThreshold[('en',2)]=17
    KThreshold[('en',3)]=16
    KThreshold[('en',4)]=16
    KThreshold[('en',5)]=16
    KThreshold[('en',6)]=16

   
    KThreshold[('de',6)]=18
    KThreshold[('de',1)]=10
    KThreshold[('de',2)]=16
    KThreshold[('de',3)]=24
    KThreshold[('de',4)]=18
    KThreshold[('de',5)]=18
    KThreshold[('en',2)]=17
    KThreshold[('en',2)]=17
